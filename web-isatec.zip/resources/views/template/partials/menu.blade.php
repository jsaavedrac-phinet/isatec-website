<ul>
    <li><a href="{{ route('web.home') }}" class="{{active('web.home') }}" >Inicio</a></li>
    <li><a>Institucional</a></li>
    <li><a>Programas de Estudio</a></li>
    <li><a>Formaci&oacute;n Continua</a></li>
    <li><a>Cursos Cortos</a></li>
    <li><a>Contacto</a></li>
    {{-- <li><a href="{{ route('web.about')}}" class="{{ active('web.about') }}">@lang('menu.about')</a></li>
@if (count($servicios) > 0)
<li class="parent">
    <a>@lang('menu.services')</a>
    <ol>
        @foreach ($servicios as $item)
        <li><a href="{{ route('web.service', $item->slug) }}">{{ $item->translateOrDefault(App::getLocale())->title }}</a></li>
        @endforeach
    </ol>
</li>
@endif
@if (count($productos) > 0)
<li class="parent">
    <a>@lang('menu.products')</a>
    <ol>
        @foreach ($productos as $item)
        <li><a href="{{ route('web.product', $item->slug) }}">{{ $item->translateOrDefault(App::getLocale())->title }}</a></li>
        @endforeach
    </ol>
</li>
@endif
<li class="parent">
    <a>@lang('menu.posts')</a>
    <ol>
        <li><a href="{{ route('web.posts', 'publicaciones.noticias') }}">@lang('menu.posts_menu.news')</a></li>
        <li><a href="{{ route('web.posts', 'publicaciones.boletin') }}">@lang('menu.posts_menu.journal')</a></li>
        <li><a href="{{ route('web.videos', 'publicaciones.video') }}">@lang('menu.posts_menu.videos')</a></li>
        <li><a href="{{ route('web.gallery',  'publicaciones.galeria') }}">@lang('menu.posts_menu.galery')</a></li>
    </ol>
</li>
<li class="{{ active('web.social-responsability') }}"><a href="{{ route('web.social-responsability') }}">@lang('menu.social_responsibility')</a></li>
<li class="{{ active('publicaciones.eventos') }}"><a href="{{ route('web.events', 'publicaciones.eventos') }}">@lang('menu.events')</a></li>
<li class="{{ active('web.contact') }}"><a href="{{ route('web.contact') }}">@lang('menu.contact')</a></li> --}}

</ul>
