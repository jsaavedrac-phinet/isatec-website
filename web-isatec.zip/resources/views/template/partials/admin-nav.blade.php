<nav class="extended">
	<div class="app_name">
		<span>CMS</span>
		<span>CMS</span>
	</div>
	<ul>
		<li class="{{active('admin.index') }}">
			<a href="{{ route('admin.index') }}" title="">
				<div class="icono"><i class="fas fa-home"></i></div>
				<div class="nav-titulo">Inicio</div>
			</a>
        </li>
        <li class="{{active(route('admin.slider.index'))}}" >
			<a href="{{ route('admin.slider.index') }}" title="">
				<div class="icono"><i class="fas fa-images"></i></div>
				<div class="nav-titulo">Sliders Index</div>
			</a>
        </li>
        {{-- <li class="{{active(route('admin.section.show_unique', 'index.bienvenida'))}}" >
			<a href="{{ route('admin.section.show_unique', 'index.bienvenida') }}" title="">
				<div class="icono"><i class="fas fa-quote-right"></i></div>
				<div class="nav-titulo">Bienvenida Index</div>
			</a>
        </li>
        <li class="{{active(route('admin.section.list', 'index.objetivos'))}}" >
                <a href="{{ route('admin.section.list', 'index.objetivos') }}" title="">
                    <div class="icono"><i class="fas fa-crosshairs"></i></div>
                    <div class="nav-titulo">Objetivos</div>
                </a>
        </li>
        <li class=" nav-parent" class="{{active(['admin/index.beneficios/*']) }}" >
			<a title="">
				<div class="icono"><i class="fas fa-coffee"></i></div>
				<div class="nav-titulo">Beneficios del Caf&eacute;</div>
				<div class="icono right"><i class="fas fa-sort-down"></i></div>
			</a>
			<ol>
				<li>
					<a href="{{ route('admin.section.show_unique', 'index.beneficios-texto') }}">
						<div class="icono"><i class="fas fa-paragraph"></i></div>
						<div class="nav-titulo">Texto</div>
					</a>
				</li>
				<li>
					<a href="{{ route('admin.section.list', 'index.beneficios-cafe') }}">
						<div class="icono"><i class="fas fa-list"></i></div>
						<div class="nav-titulo">Beneficios</div>
					</a>
				</li>
			</ol>
        </li>
        <li class="{{active(route('admin.section.show_unique', 'index.contactanos'))}}" >
                <a href="{{ route('admin.section.show_unique', 'index.contactanos') }}" title="">
                    <div class="icono"><i class="fas fa-phone-square-alt"></i></div>
                    <div class="nav-titulo">Contactanos Index</div>
                </a>
        </li>
        <li class="{{active(route('admin.section.list', 'sponsors'))}}" >
                <a href="{{ route('admin.section.list', 'sponsors') }}" title="">
                    <div class="icono"><i class="fas fa-ad"></i></div>
                    <div class="nav-titulo">Sponsor</div>
                </a>
        </li>
        <li class=" nav-parent" class="{{active(['admin/about/*']) }}" >
			<a title="">
				<div class="icono"><i class="fas fa-info-circle"></i></div>
				<div class="nav-titulo">Quienes somos</div>
				<div class="icono right"><i class="fas fa-sort-down"></i></div>
			</a>
			<ol>
				<li>
					<a href="{{ route('admin.section.show_unique', 'quienes-somos.banner') }}">
						<div class="icono"><i class="fas fa-image"></i></div>
						<div class="nav-titulo">Banner</div>
					</a>
				</li>
				<li>
					<a href="{{ route('admin.section.show_unique', 'quienes-somos.texto') }}">
						<div class="icono"><i class="fas fa-info"></i></div>
						<div class="nav-titulo">Quienes somos</div>
					</a>
				</li>
				<li>
					<a href="{{ route('admin.section.show_unique', 'quienes-somos.historia') }}">
						<div class="icono"><i class="fas fa-history"></i></div>
						<div class="nav-titulo">Historia</div>
					</a>
				</li>
				<li>
					<a href="{{ route('admin.section.show_unique', 'quienes-somos.mision') }}">
						<div class="icono"><i class="fas fa-bullseye"></i></div>
						<div class="nav-titulo">Misi&oacute;n</div>
					</a>
				</li>
				<li>
					<a href="{{ route('admin.section.show_unique', 'quienes-somos.vision') }}">
						<div class="icono"><i class="fas fa-eye"></i></div>
						<div class="nav-titulo">Visi&oacute;n</div>
					</a>
                </li>
                <li>
					<a href="{{ route('admin.section.list', 'quienes-somos.valores') }}">
						<div class="icono"><i class="fas fa-heart"></i></div>
						<div class="nav-titulo">Valores y Principios</div>
					</a>
				</li>
                <li>
					<a href="{{ route('admin.section.list', 'quienes-somos.estructura-organica') }}">
						<div class="icono"><i class="fas fa-sitemap"></i></div>
						<div class="nav-titulo">Estructura Org&aacute;nica</div>
					</a>
				</li>
			</ol>
        </li>
        <li class="{{active(route('admin.section.list', 'servicios'))}}" >
            <a href="{{ route('admin.section.list', 'servicios') }}" title="">
                <div class="icono"><i class="fas fa-concierge-bell"></i></div>
                <div class="nav-titulo">Servicios</div>
            </a>
        </li>
        <li class="{{active(route('admin.section.list', 'productos'))}}" >
            <a href="{{ route('admin.section.list', 'productos') }}" title="">
                <div class="icono"><i class="fas fa-mug-hot"></i></div>
                <div class="nav-titulo">Productos</div>
            </a>
        </li>
        <li class=" nav-parent" class="{{active(['admin/responsabilidad-social/*']) }}" >
			<a title="">
				<div class="icono"><i class="fas fa-hand-holding-heart"></i></div>
				<div class="nav-titulo">R. Social</div>
				<div class="icono right"><i class="fas fa-sort-down"></i></div>
			</a>
			<ol>
				<li>
					<a href="{{ route('admin.section.show_unique', 'responsabilidad-social.banner') }}">
						<div class="icono"><i class="fas fa-image"></i></div>
						<div class="nav-titulo">Banner</div>
					</a>
                </li>
				<li>
					<a href="{{ route('admin.section.show_unique', 'responsabilidad-social.texto') }}">
						<div class="icono"><i class="fas fa-paragraph"></i></div>
						<div class="nav-titulo">Texto</div>
					</a>
                </li>
                <li>
                    <a href="{{ route('admin.section.list', 'responsabilidad-social.contenido') }}">
                        <div class="icono"><i class="fas fa-puzzle-piece"></i></div>
                        <div class="nav-titulo">Contenido</div>
                    </a>
                </li>
			</ol>
        </li>
        <li class=" nav-parent" class="{{active(['admin/posts/*']) }}" >
			<a title="">
				<div class="icono"><i class="fas fa-newspaper"></i></div>
				<div class="nav-titulo">Publicaciones</div>
				<div class="icono right"><i class="fas fa-sort-down"></i></div>
			</a>
			<ol>
				<li>
					<a href="{{ route('admin.section.show_unique', 'publicaciones.banner') }}">
						<div class="icono"><i class="fas fa-image"></i></div>
						<div class="nav-titulo">Banner</div>
					</a>
                </li>
                <li>
                    <a href="{{ route('admin.post.list', 'publicaciones.noticias') }}">
                        <div class="icono"><i class="fas fa-newspaper"></i></div>
                        <div class="nav-titulo">Noticias</div>
                    </a>
                </li>
                <li>
                    <a href="{{ route('admin.post.list', 'publicaciones.eventos') }}">
                        <div class="icono"><i class="fas fa-calendar-alt"></i></div>
                        <div class="nav-titulo">Eventos</div>
                    </a>
                </li>
                <li>
                    <a href="{{ route('admin.post.list', 'publicaciones.boletin') }}">
                        <div class="icono"><i class="fas fa-journal-whills"></i></div>
                        <div class="nav-titulo">Boletin</div>
                    </a>
                </li>
                <li>
                    <a href="{{ route('admin.section.list', 'publicaciones.video') }}">
                        <div class="icono"><i class="fas fa-video"></i></div>
                        <div class="nav-titulo">Video</div>
                    </a>
                </li>
                <li>
                    <a href="{{ route('admin.section.list', 'publicaciones.galeria') }}">
                        <div class="icono"><i class="fas fa-camera"></i></div>
                        <div class="nav-titulo">Galeria</div>
                    </a>
                </li>


			</ol>
		</li>--}}
		<li class="{{active(route('admin.settings.index'))}}" >
            <a href="{{ route('admin.settings.index') }}" title="">
                <div class="icono"><i class="fas fa-cogs"></i></div>
                <div class="nav-titulo">Opciones</div>
            </a>
        </li>

	</ul>
</nav>
