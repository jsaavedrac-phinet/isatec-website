{{-- @if (count($sponsors))
<section class="sponsors">
@foreach ($sponsors as $item)
<div class="sponsor">
    <picture>
    <source class="lazy" data-srcset="{{ asset('storage/images/'.$item->image->webp)}}" type="image/webp">
    <source class="lazy" data-srcset="{{ asset('storage/images/'.$item->image->url)}}" type="image/{{ $item->image->extension }}">
    <img class="lazy" data-src="{{ asset('storage/images/'.$item->image->url) }}" alt="{{ $item->title }}">
    </picture>
</div>
@endforeach
</section>
@endif

 --}}

 <footer>

	<div class="fullbox">
		Desarrollado por :&nbsp;<a href="https://www.phinet.com/" target="_blank">Phinet</a>
	</div>
</footer>
