@extends('template.web')
@section('title')
@lang('menu.about')
@endsection
@section('css')
<style type="text/css">
    @font-face {
		font-family: Satisfy;
		src:  url({{ asset('fonts/Satisfy/Satisfy-Regular.ttf') }});
		font-weight: normal;
		font-style: normal;
		font-display: swap;
		}
    section{
        padding: 4em 4em;
        width:  calc(100% - 8em);
        display: flex;
        flex-wrap: wrap;
        justify-content: space-evenly;
        color: #222;
        background-repeat: no-repeat !important;
        background-position: center !important;
        background-size: cover !important;
    }
    .parallax{background-attachment: fixed !important;}
    .space-between{justify-content: space-between;}
    .align-center{align-items: center;}
    .space-evenly{justify-content: space-evenly;}

    section:nth-of-type(2n+2){background: var(--main_color); color: #FFF;}
    section:nth-of-type(2n+2) h2{color: #FFF;}
    section:nth-of-type(2n+2) h3{color: #FFF;}
    section .content{width: calc(100% - 2em); max-width: calc(600px - 2em); display: flex; flex-direction: column; flex-wrap: wrap; justify-content: space-between;}
    section h2{font-size: 2em; color: var(--main_color); width: 100%;}
    section h3{font-size: 2.5em; font-weight: bolder; margin: 0.5em 0; width: 100%;}
    section h4, section h5, section h6{width: 100%; margin: 1em 0;}
    section .text-center{text-align: center;}
    section .text{font-weight: 300; color: inherit}
    section .image{width: calc(100% - 2em); max-width: calc(600px - 2em); text-align: center; overflow: hidden;}
    section .image.image-rounded{border-radius: 15px;}
    section .image img{width: auto; height: auto; max-width: 100%;}
    section ul{width: 100%; display: flex; justify-content: space-evenly; flex-wrap: wrap; margin-top: 2em;}
    section ul li{margin: 0.3em 0; width: calc(100% - 2em); max-width: calc(300px - 2em); text-align: center; list-style: none;}
    section ul li img{width: auto; height: auto; max-width: 150px; max-height: 150px;}
    section ul li .text{margin-top: 1em; font-weight: 300; font-weight: bold; color: inherit}
    .button{width: 100%; display: flex; justify-content: flex-end; padding:  1em 0;}
    .button a{text-decoration: none; cursor: pointer; border-radius: 24px; background: var(--main_color); color: #FFF; padding: 1em; font-weight: bolder; color:  var(--highlight_color)}

    section .subsection{width: 100%; margin: 1em 0;}
    section.myv .image-content li{background: rgba(0,0,0,.4); padding:  1em;}
    .banner{ height: calc(100vh - 100px); display: flex; justify-content: center; align-items: center; color: #FFF; background-repeat: no-repeat !important;        background-position: center !important; background-size: cover !important;}
    .banner *{color: inherit;}
    .banner div{background: rgba(0,0,0,.4); padding:  1em; font-size: 1.4em;}

    .myv{ text-align: initial}
    .myv ul li{text-align: inherit;}
    @media (max-width: 769px){
        section{width: calc(100% - 2em); padding: 2em 1em;}
        section .image{margin: 1em 0;}
    }
</style>
@endsection
@section('content')
@if ($banner != null)
<div class="banner" style="background: url({{ asset('storage/images/'.$banner->image->url)}});background: url({{ asset('storage/images/'.$banner->image->webp)}})">
    <div>{!! $banner->translateOrDefault(\App::getLocale())->content!!}</div>
</div>
@endif

@if ($about != null)
<section>
    <div class="content">
        <div class="content-aux">
            <h2>{{ $about->translateOrDefault(\App::getLocale())->title }}</h2>
            @if ($about->translateOrDefault(\App::getLocale())->subtitle !== '')
            <h3>{{ $about->translateOrDefault(\App::getLocale())->subtitle }}</h3>
            @endif
            <div class="text">
                {!! $about->translateOrDefault(\App::getLocale())->content !!}
            </div>
        </div>
    </div>
    <div class="image image-rounded">
        <picture>
            <source class="lazy" data-srcset="{{ asset('storage/images/'.$about->image->webp) }}" type="image/webp">
            <source class="lazt" data-srcset="{{ asset('storage/images/'.$about->image->url) }}" type="image/{{ $about->image->extension }}" >
            <img class="lazy" data-src="{{ asset('storage/images/'.$about->image->url) }}" >
        </picture>
    </div>
</section>
@endif
@if ( $mision != null || $vision != null )
<section class="myv" style="background: url({{ asset('storage/settings/bg-myv.jpg')}});background: url({{ asset('storage/settings/bg-myv.webp')}})">
    <ul class="image-content">
        @if ($mision != null)
        <li>
            <h3>{{ $mision->translateOrDefault(\App::getLocale())->title }}</h3>
            @if ($mision->translateOrDefault(\App::getLocale())->subtitle !== '')
            <h4>{{ $mision->translateOrDefault(\App::getLocale())->subtitle }}</h4>
            @endif
            <div class="text">
                {!! $mision->translateOrDefault(\App::getLocale())->content !!}
            </div>
        </li>
        @endif
        @if ($vision != null)
        <li>
            <h3>{{ $vision->translateOrDefault(\App::getLocale())->title }}</h3>
            @if ($vision->translateOrDefault(\App::getLocale())->subtitle !== '')
            <h4>{{ $vision->translateOrDefault(\App::getLocale())->subtitle }}</h4>
            @endif
            <div class="text">
                {!! $vision->translateOrDefault(\App::getLocale())->content !!}
            </div>
        </li>
        @endif


    </ul>

</section>
@endif
@if ($historia != null)
<section>
    <div class="image image-rounded">
        <picture>
            <source class="lazy" data-srcset="{{ asset('storage/images/'.$historia->image->webp) }}" type="image/webp">
            <source class="lazt" data-srcset="{{ asset('storage/images/'.$historia->image->url) }}" type="image/{{ $historia->image->extension }}" >
            <img class="lazy" data-src="{{ asset('storage/images/'.$historia->image->url) }}" >
        </picture>
    </div>
    <div class="content">
        <div class="content-aux">
            <h2>{{ $historia->translateOrDefault(\App::getLocale())->title }}</h2>
            @if ($historia->translateOrDefault(\App::getLocale())->subtitle !== '')
            <h3>{{ $historia->translateOrDefault(\App::getLocale())->subtitle }}</h3>
            @endif
            <div class="text">
                {!! $historia->translateOrDefault(\App::getLocale())->content !!}
            </div>
        </div>
    </div>
</section>
@endif
@if ( count($valores) > 0)
<section>
    <h2 class="text-center">@lang('messages.values')</h2>
    <ul class="image-content">
        @foreach ($valores as $item)
        <li>
            <picture>
                <source class="lazy" data-srcset="{{ asset('storage/images/'.$item->image->webp)}}" type="image/webp">
                <source class="lazy" data-srcset="{{ asset('storage/images/'.$item->image->url)}}" type="image/{{ $item->image->extension }}">
                <img class="lazy" data-src="{{ asset('storage/images/'.$item->image->url)}}" alt="{!! $item->translateOrDefault(\App::getLocale())->content !!}">
            </picture>
            <div class="text">
                {!! $item->translateOrDefault(\App::getLocale())->title !!}
            </div>
        </li>
        @endforeach
    </ul>

</section>
@endif
@if (count($estructura_organica) > 0)
<section>
    <h2 class="text-center">@lang('messages.organic-structures')</h2>
    @foreach ($estructura_organica as $item)
    <div class="subsection">
    <h3>{{ $item->translateOrDefault(App::getLocale())->title }}</h3>
    @if ($item->translateOrDefault(App::getLocale())->subtitle !== '')
    <h4>{{ $item->translateOrDefault(App::getLocale())->subtitle }}</h4>
    @endif
    <div class="text">
        {!! $item->translateOrDefault(App::getLocale())->content !!}
    </div>
    </div>
    @endforeach
</section>
@endif
@endsection
