<?php $__env->startSection('title','Inicio'); ?>
<?php $__env->startSection('css'); ?>
<style type="text/css">
.bienvenida{width: 100%; height: calc(100vh - 112px); text-align: center; display: flex; justify-content: center; align-items: center; color: var(--verde_logo);}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="bienvenida">
	<h1>Bienvenid@ al Dashboard</h1>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\isatec\resources\views/admin/index.blade.php ENDPATH**/ ?>