<div class="nav-bar">
    <div class="social">
        <?php if($facebook !== null && $facebook->value != ''): ?>
            <a href="<?php echo e($facebook->value); ?>" target="_blank"><i class="fab fa-facebook"></i></a>&nbsp;
        <?php endif; ?>
        <?php if($youtube !== null && $youtube->value != ''): ?>
            <a href="<?php echo e($youtube->value); ?>" target="_blank"><i class="fab fa-youtube"></i></a>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\LARAVEL\isatec\resources\views/template/partials/nav-bar.blade.php ENDPATH**/ ?>