<ul>
    <li><a href="<?php echo e(route('web.home')); ?>" class="<?php echo e(active('web.home')); ?>" >Inicio</a></li>
    <li><a>Institucional</a></li>
    <li><a>Programas de Estudio</a></li>
    <li><a>Formaci&oacute;n Continua</a></li>
    <li><a>Cursos Cortos</a></li>
    <li><a>Contacto</a></li>
    

</ul>
<?php /**PATH D:\LARAVEL\isatec\resources\views/template/partials/menu.blade.php ENDPATH**/ ?>