

 <footer>

	<div class="fullbox">
		Desarrollado por :&nbsp;<a href="https://www.phinet.com/" target="_blank">Phinet</a>
	</div>
</footer>
<?php /**PATH D:\LARAVEL\isatec\resources\views/template/partials/footer.blade.php ENDPATH**/ ?>