<?php $__env->startSection('title','Inicio'); ?>
<?php $__env->startSection('css'); ?>
<style type="text/css">
    section{
        padding: 4em 4em;
        width:  calc(100% - 8em);
        display: flex;
        flex-wrap: wrap;
        justify-content: space-evenly;
        color: #222;
        background-repeat: no-repeat !important;
        background-position: center !important;
        background-size: cover !important;
    }
    .parallax{background-attachment: fixed !important;}
    .space-between{justify-content: space-between;}
    .align-center{align-items: center;}
    .space-evenly{justify-content: space-evenly;}

    section:nth-of-type(2n+2){background: var(--main_color); color: #FFF;}
    section:nth-of-type(2n+2) h2{color: #FFF;}
    section:nth-of-type(2n+2) h3{color: #FFF;}
    section .content{width: calc(100% - 2em); max-width: calc(600px - 2em); display: flex; flex-direction: column; flex-wrap: wrap; justify-content: space-between;}
    section h2{font-size: 2em; color: var(--main_color); width: 100%;}
    section h3{font-size: 2.5em; font-weight: bolder; margin: 0.5em 0; width: 100%;}
    section h4, section h5, section h6{width: 100%; margin: 1em 0;}
    section .text-center{text-align: center;}
    section .text{font-weight: 300; color: inherit}
    section .image{width: calc(100% - 2em); max-width: calc(600px - 2em); text-align: center; overflow: hidden;}
    section .image.image-rounded{border-radius: 15px;}
    section .image img{width: auto; height: auto; max-width: 100%;}
    section ul{width: 100%; display: flex; justify-content: space-evenly; flex-wrap: wrap; margin-top: 2em;}
    section ul li{margin: 0.3em 0; width: calc(100% - 2em); max-width: calc(300px - 2em); text-align: center; list-style: none;}
    section ul li img{width: auto; height: auto; max-width: 150px; max-height: 150px;}
    section ul li .text{margin-top: 1em; font-weight: 300; font-weight: bold; color: inherit}
    .slides {
        width: 100%;
        height: 720px;
        overflow: hidden;
        position: relative;
    }
    .slides .arrow{
        height: 100%;
        position: absolute;
        top: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 3;
        font-size: 2em;
    }
    .slides .arrow span{
        background: rgba(0,0,0,0.6);
        padding: 0 1em;
        color: #FFF;
        cursor: pointer;
    }
    .slider .arrow.left{
        left: 0;
    }

    .slides .arrow.right{
        right: 0;
    }
    .slides .slide{
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        right: -100%;
    }
    .slides .slide .text{position: absolute; top:0; left: 0; display: flex; justify-content: center; align-items: center; color: #FFF; width: 100%; height: 100%; font-size: calc(12px + 2.5em);}
    .slides .slide .text *{font-family: inherit; text-decoration: none; color: #FFF;}
    .slides .slide .text div{padding:  1em;}
    .slides .slide .text div a{padding: 0.3em; border-radius: 6px; background: #06C4C0; margin: 0.5em 0; display: inline-block; font-size: 0.8em; }
    .slides .slide .text div h2{background: #06C4C0; padding: 0.2em; font-size: 0.9em; white-space: pre; display: inline-block; }
    .slides .slide img{width: 100%; height: auto;}

    .slides .slide.right .text{width: 40%; left: 60%;}
    .slides .slide.right .text div p{width: calc(100% - 1em); padding-left: 1em;}
    .slides .slide.left .text{width: 40%;}
    .slides .slide.left .text div p{width: calc(100% - 1em); padding-left: 1em;}
    .slides .slide.center .text{width: 100%; left: 0%;}
    .slides .slide.right-bg .text{width: 40%; background: rgba(1,0,252,0.57); left: 60%;}
    .slides .slide.right-bg .text div p{width: calc(100% - 1em); padding-left: 1em;}
    .slides .slide.right-bg .text::before{position: absolute;
        content: "";
        width: 0;
        height: 0;
        border-bottom: calc(100vh - 130px) solid rgba(1,0,252,0.57);
        border-left: calc( (100vh - 130px) * 0.30) solid
        transparent;
        top: 0;
        right: 100%;}
    .slides .slide.left-bg .text{width: 40%; background: rgba(1,0,252,0.57);}
    .slides .slide.left-bg .text div p{width: calc(100% - 1em); padding-left: 1em;}
    .slides .slide.left-bg .text::before{position: absolute;
        content: "";
        width: 0;
        height: 0;
        border-bottom: calc(100vh - 130px) solid rgba(1,0,252,0.57);
        border-right: calc( (100vh - 130px) * 0.30) solid
        transparent;
        top: 0;
        left: 100%;}
    .slides .slide.center-bg .text div{background: rgba(1,0,252,0.57); width: 70%; height: auto;}
    .button{width: 100%; display: flex; justify-content: flex-end; padding:  1em 0;}
    .button a{text-decoration: none; cursor: pointer; border-radius: 24px; background: var(--main_color); color: #FFF; padding: 1em; font-weight: bolder; color:  var(--highlight_color)}

    .beneficios-container{display: flex; justify-content: space-between; margin-top: 2em;}
    .beneficios-container .image{order: 2; width: calc(100% - 2em); max-width: calc(500 - 2em); padding: 0 1em;}
    .beneficios-container .image img{width: auto; height: auto; max-width: 100%;}

    .beneficios-container .beneficios{width: calc(100% - 2em); max-width: calc(350px - 2em); padding:  0 1em; display: flex; flex-wrap: wrap; flex-direction: column; justify-content: space-evenly;}
    .beneficios-container .beneficios .beneficio .text *{text-align: inherit }
    .beneficios-container .beneficios.izquierda{order:1}
    .beneficios-container .beneficios.izquierda .beneficio h2{text-align: right;}
    .beneficios-container .beneficios.izquierda .beneficio .text{text-align: right;}
    .beneficios-container .beneficios.derecha{order:3}
    .beneficios-container .beneficios.derecha .beneficio h2{text-align: left;}
    .beneficios-container .beneficios.derecha .beneficio .text{text-align: left;}
    .index-contactanos{height: 634px;}
    section .box .text{font-size: calc(20px + 0.5vw);}
    section .box .text strong{font-weight: 900;}
    @media (max-width: 769px){
        section{width: calc(100% - 2em); padding: 2em 1em;}
        .beneficios-container{flex-wrap: wrap;}
        .beneficios-container .image{margin: 1em 0;}
        .index-contactanos{height: 254px;}
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(count($slides) > 0): ?>
<div class="slides">
    <div class="arrow left">
        <span class="fas fa-angle-left"></span>
    </div>
    <div class="slides-box">
    <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="slide <?php echo e(str_replace(".png","",$slide->style)); ?> <?php echo e($key == 0 ? 'active' : ''); ?>" style="<?php echo e($key == 0 ? 'right: 0' : ''); ?>">
        <picture>
            <source class="lazy" data-srcset="<?php echo e(asset('storage/images/'.$slide->image->webp)); ?>" type="image/webp">
            <source class="lazy" data-srcset="<?php echo e(asset('storage/images/'.$slide->image->url)); ?>" type="image/<?php echo e($slide->image->extension); ?>">
            <img class="lazy" data-src="<?php echo e(asset('storage/images/'.$slide->image->url)); ?>" alt="<?php echo e(\Illuminate\Support\Str::slug(strip_tags(\Illuminate\Support\Str::words($slide->content, 15,'')))); ?>">
        </picture>
        <div class="text">
            <div>
                <?php echo $slide->content; ?>

            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="arrow right">
            <span class="fas fa-angle-right"></span>
    </div>
</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('archivojs'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script type="text/javascript">
    var tiempo = 7000;

    var interizq =setInterval(function(){
      izquierda();
    },tiempo);
    clearInterval(interizq);

    var interder =setInterval(function(){
     derecha();
    },tiempo);

    function recorrer(){
      estado=false;

      var elementos = $('.slides-box .slide');
      var cont=0;
      $.each(elementos,function(){
        cont++;
      })

      if(cont>1){estado=true};

      return estado;
    }
   $(document).on('click','.arrow.right',function(){
      clearInterval(interizq);
      clearInterval(interder);
      derecha();
   });

    $(document).on('click','.arrow.left',function(){
        clearInterval(interizq);
        clearInterval(interder);
        izquierda();
    });
    function derecha(){
        if (recorrer()) {
            var elementos = $('.slides-box .slide');
            var total=0;
            var actual=0;
            var sgte=0;
            $.each(elementos,function(){
                total++;
                var clase= $(this).attr('class');
                if (clase.indexOf("active") != -1) {
                sgte = parseInt($(this).index())+parseInt(1);
                actual = parseInt($(this).index());
                }
                $(this).removeClass('active');
            })
            if (sgte==total) {
                sgte=0;
            }
            $.each(elementos,function(){

                if ($(this).index()==actual) {
                    $(this).animate({right:"100%"},700);
                }
                if ($(this).index()==sgte) {
                    $(this).css('right','-100%');
                    $(this).addClass('active');
                    $(this).animate({right:"0%"},700);
                }
        });

        clearInterval(interizq);
        clearInterval(interder);
        interder =setInterval(function(){
            derecha();
        },tiempo);
        }
   }

   function izquierda(){
    if(recorrer()){
        var elementos = $('.slides-box .slide');
        var total=0;
        var actual=0;
        var sgte=0;
        $.each(elementos,function(){
            total++;
            var clase= $(this).attr('class');
            if (clase.indexOf("active") != -1) {

            sgte = parseInt($(this).index())-parseInt(1);
            actual = parseInt($(this).index());

            }
            $(this).removeClass('active');
        })
        if (sgte==-1) {
            sgte=total-1;
        }

      $.each(elementos,function(){
        if ($(this).index()==actual) {
          $(this).animate({right:"-100%"},700);
        }
        if ($(this).index()==sgte) {
          $(this).css('right','100%');
          $(this).animate({right:"0%"},700);
          $(this).addClass('active');
        }
      })


      clearInterval(interizq);
      clearInterval(interder);
      interizq =setInterval(function(){
        izquierda();
      },tiempo);
    }


    }


  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\isatec\resources\views/web/index.blade.php ENDPATH**/ ?>