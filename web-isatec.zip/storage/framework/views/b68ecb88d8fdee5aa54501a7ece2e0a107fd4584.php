<header id="header" class="web">
    <?php echo $__env->make('template.partials.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="header">
        <div class="logo">
            <div class="imagen">
                <picture>
                    <source class="lazy" data-src="<?php echo e(asset('storage/settings/logo-original.webp')); ?>" type="image/webp">
                    <img class="lazy" data-src="<?php echo e(asset('storage/settings/logo-original.png')); ?>" alt="logo-inprocafe">
                </picture>
            </div>
        </div>
        <div class="menu">
            <div class="menu_nav">
                <?php echo $__env->make('template.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</header>
<header id="header" class="mobile">
    <?php echo $__env->make('template.partials.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="logo">
        <div class="imagen">
            <picture>
                <source class="lazy" data-src="<?php echo e(asset('storage/settings/logo-original.webp')); ?>" type="image/webp">
                <img class="lazy" data-src="<?php echo e(asset('storage/settings/logo-original.png')); ?>" alt="logo-inprocafe">
            </picture>
        </div>
    </div>
    <div class="menu">
        <div class="menu_nav">
            <div class="btn_menu"><i class="fas fa-bars"></i></div>
            <div class="menu-mobile">
                <div class="btn-aux">
                    <div class="btn-cerrar">x</div>
                    <?php echo $__env->make('template.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>

    </div>
</header>
<?php /**PATH D:\LARAVEL\isatec\resources\views/template/partials/nav.blade.php ENDPATH**/ ?>