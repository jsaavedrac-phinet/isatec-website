<header class="extended">
	<div class="icono-menu">
        <i class="fas fa-caret-left"></i>
	</div>
	<div class="tabs <?php echo e(active('admin.index')); ?>">
		<div class="container-tabs">
			<a  class="active" href="<?php echo e(route('admin.index')); ?>">Dashboard</a>
			<?php echo $__env->yieldContent('tab-parent'); ?>
			<a ><?php echo $__env->yieldContent('title'); ?></a>
		</div>
	</div>
	<div class="menu-user-container">
		<div class="avatar">
            <span> Hola, <?php echo e(Auth::user()->name); ?>&nbsp; </span>
            <?php if(Auth::user()->image !== null): ?>
            <picture>
                <source srcset="<?php echo e(asset('storage/images/'.Auth::user()->image->webp)); ?>" type="image/webp">
                <source srcset="<?php echo e(asset('storage/images/'.Auth::user()->image->url)); ?>" type="image/<?php echo e(Auth::user()->image->extension); ?>" >
                <img src="<?php echo e(asset('storage/images/'.Auth::user()->image->url)); ?>">
            </picture>
            <?php else: ?>
            <picture>
                <source srcset="<?php echo e(asset('storage/images/default.webp')); ?>" type="image/webp">
                <source srcset="<?php echo e(asset('storage/images/default.png')); ?>" type="image/png" >
                <img src="<?php echo e(asset('storage/images/default.png')); ?>">
            </picture>
            <?php endif; ?>

			<div class="show-menu-user">
                    <i class="fas fa-caret-down"></i>
			</div>
		</div>
		<div class="menu-user">
			<div class="menu-option">
				<a href="<?php echo e(route('admin.profile')); ?>">
					<div class="icono-menu-user">
                            <i class="fas fa-user-circle"></i>
					</div>
					<div class="title-option">
						Perfil
					</div>
				</a>
			</div>
			<div class="menu-option">
				<a href="<?php echo e(route('web.home')); ?>" target="_blank">
					<div class="icono-menu-user">
                            <i class="fas fa-globe"></i>
					</div>
					<div class="title-option">
						Ir a la Web
					</div>
				</a>
			</div>
			<div class="menu-option">
				<a class="btn-logout" href="" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i> &nbsp;Cerrar Sesi&oacute;n</a>
			<form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;"><?php echo csrf_field(); ?></form>
		</div>
	</div>
</div>
</header>
<?php /**PATH D:\LARAVEL\isatec\resources\views/template/partials/admin-bar.blade.php ENDPATH**/ ?>