<nav class="extended">
	<div class="app_name">
		<span>CMS</span>
		<span>CMS</span>
	</div>
	<ul>
		<li class="<?php echo e(active('admin.index')); ?>">
			<a href="<?php echo e(route('admin.index')); ?>" title="">
				<div class="icono"><i class="fas fa-home"></i></div>
				<div class="nav-titulo">Inicio</div>
			</a>
        </li>
        <li class="<?php echo e(active(route('admin.slider.index'))); ?>" >
			<a href="<?php echo e(route('admin.slider.index')); ?>" title="">
				<div class="icono"><i class="fas fa-images"></i></div>
				<div class="nav-titulo">Sliders Index</div>
			</a>
        </li>
        
		<li class="<?php echo e(active(route('admin.settings.index'))); ?>" >
            <a href="<?php echo e(route('admin.settings.index')); ?>" title="">
                <div class="icono"><i class="fas fa-cogs"></i></div>
                <div class="nav-titulo">Opciones</div>
            </a>
        </li>

	</ul>
</nav>
<?php /**PATH D:\LARAVEL\isatec\resources\views/template/partials/admin-nav.blade.php ENDPATH**/ ?>