<footer>
	Desarrollado por&nbsp;<a href="https://phinet.com" target="_blank">Phinet</a>
</footer><?php /**PATH D:\LARAVEL\isatec\resources\views/template/partials/admin-footer.blade.php ENDPATH**/ ?>