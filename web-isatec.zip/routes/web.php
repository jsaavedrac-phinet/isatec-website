<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::name('web.')->group(function(){
    Route::get('/', 'WebController@index')->name('home');
    // Route::post('/changeLocale','WebController@changeLocale');
    // Route::get('/about','WebController@about')->name('about');
    // Route::get('/service/{slug}/info','WebController@service')->name('service');
    // Route::get('/product/{slug}/info','WebController@product')->name('product');
    // Route::get('/social-responsability','WebController@social_responsability')->name('social-responsability');
    // Route::get('/posts/{type}','WebController@posts')->name('posts');
    // Route::get('/events/{type}','WebController@events')->name('events');
    // Route::get('/videos/{type}','WebController@videos')->name('videos');
    // Route::get('/gallery/{type}','WebController@gallery')->name('gallery');
    // Route::get('/posts/{type}/{post}/read','WebController@post')->name('post');
    // Route::get('/events/{type}/{event}/read','WebController@event')->name('event');
    // Route::get('/videos/{type}/{video}/read','WebController@video')->name('video');
    // Route::get('/contact','WebController@contact')->name('contact');
});
Route::name('admin.')->prefix('admin')->group(function(){
	Auth::routes();
	// CARGAR POR DEFECTO EL LOGIN
	Route::get('/','Auth\LoginController@showLoginForm')->name('login');
	// VERIFICAR USUARIO
	Route::post('/','Auth\LoginController@login')->name('verificar');
	Route::middleware(['auth','optimizeImages'])->group(function(){
		// CARGA INDEX ADMINISTRADOR
		// Route::post('upload_images','AdminController@imagenes')->name('up_images');
		// Route::post('upload_videos','AdminController@videos')->name('up_videos');
		Route::get('index','AdminController@index')->name('index');
		Route::post('index','AdminController@cambiar_clave')->name('index');
		Route::get('profile','AdminController@profile')->name('profile');
		Route::post('profile','AdminController@edit_profile')->name('edit_profile');
		//OPCIONES DE CONFIGURACION
		Route::name('settings.')->prefix('settings')->group(function(){
			Route::get('/','SettingController@index')->name('index');
			Route::post('/','SettingController@store')->name('store');
        });

        //Section
        Route::name('section.')->prefix('section')->group(function(){
            Route::get('{tipo}/sort','SectionController@sort')->name('sort');
            Route::post('{tipo}/sort','SectionController@order')->name('order');
            Route::get('{tipo}/list','SectionController@index')->name('list');
            Route::post('{tipo}/list','SectionController@destroy')->name('destroy');
            Route::get('{tipo}/create','SectionController@create')->name('create');
            Route::post('{tipo}/create','SectionController@store')->name('store');
            Route::get('{tipo}/{section}','SectionController@show')->name('show')->where('id', '[0-9]+');
            Route::post('{tipo}/{section}','SectionController@update')->name('update')->where('id', '[0-9]+');
            Route::get('{tipo}','SectionController@show_unique')->name('show_unique');
            Route::post('{tipo}','SectionController@update_unique')->name('update_unique');
            Route::get('{tipo}/translate/{section}','SectionController@translate')->name('translate');
            Route::post('{tipo}/translate/{section}','SectionController@update_translate')->name('update_translate');
        });

        //Posts
        Route::name('post.')->prefix('post')->group(function(){
            Route::get('{tipo}/list','PostController@index')->name('list');
            Route::get('{tipo}/create','PostController@create')->name('create');
            Route::post('{tipo}/create','PostController@store')->name('store');
            Route::post('{tipo}/list','PostController@destroy')->name('destroy');

            Route::get('{tipo}/{post}','PostController@show')->name('show')->where('id', '[0-9]+');
            Route::post('{tipo}/{post}','PostController@update')->name('update')->where('id', '[0-9]+');

            Route::get('{tipo}/translate/{post}','PostController@translate')->name('translate');
            Route::post('{tipo}/translate/{post}','PostController@update_translate')->name('update_translate');
        });
		// GESTION DEL SLIDER DEL INDEX
		Route::name('slider.')->prefix('slider')->group(function(){
			Route::get('/','SliderController@index')->name('index');
			Route::post('/','SliderController@destroy')->name('destroy');
			Route::get('/create','SliderController@create')->name('create');
			Route::post('/create','SliderController@store')->name('store');
			Route::get('/edit/{slider}','SliderController@edit')->name('edit');
			Route::post('/edit/{slider}','SliderController@update')->name('update');
			Route::get('/sort','SliderController@sort')->name('sort');
            Route::post('/sort','SliderController@order')->name('order');
		});


	});
});
