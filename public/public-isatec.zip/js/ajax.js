$(function(){
	$(document).on('click','button[type=submit]',function(event){

		if(!$(this).hasClass('trumbowyg-modal-submit')){
		var id = $(this).attr('numero');
		event.preventDefault();
		var data = new FormData($('form#'+id)[0]);
		var delete_message=false;
		for (var pair of data.entries()) {
		     if (pair[1]==="delete") {
		    	delete_message = true;
		     }
		}

		if (delete_message) {
			Swal.fire({
			  title: "Estás seguro?",
			  text: "No podras recuperarlo en el futuro",
			  type: "warning",
			  showCancelButton: true,
			  confirmButtonColor: "#DD6B55",
			  confirmButtonText: "Sí, borralo!",
			  cancelButtonText: "Cancelar",

			}).then((result)=>{
				if(result.value){
					send();
				}
			})
		}else{
			send();
		}


		function send(){
			Swal.fire({
			  title: 'Por favor, espere...',
			  showConfirmButton: false,
			});
			$.ajax({
				url: window.location.href,
				data: data,
				type: 'POST',
				contentType: false,
				processData: false,
				cache: false,
				success: function(data){
					console.log(data);
                    if(data.type != null && data.type == "error"){
						Swal.fire({
							  type: 'error',
							  title: 'Oops...',
							  html: data.message,
							  footer: '<center>Toma una captura y enviala al soporte para ayudarte con el problema</center>'
						})
					}else if(data.message != null){
						if(data.login != null && data.login == true){
							var timerInterval;
							Swal.fire({
							  type: 'success',
							  title: 'Guardando cambios...',
							  html: 'La ventana se cerrará en <strong></strong> segundos.',
							  timer: 5000,
							  onBeforeOpen: () => {
							    Swal.showLoading()
							    timerInterval = setInterval(() => {
							      Swal.getContent().querySelector('strong')
							        .textContent = Swal.getTimerLeft()
							    }, 100)
							  },
							  onClose: () => {
							    clearInterval(timerInterval)
							  }
							}).then((result) => {
							  if (
							    // Read more about handling dismissals
							    result.dismiss === Swal.DismissReason.timer
							  ) {
							  	window.location.reload();
							    console.log('I was closed by the timer')
							  }
							})
						}else{
							localStorage.setItem('mensaje',data.message);
							window.location.reload();
						}

					}else{
						Swal.fire({
							  type: 'error',
							  title: 'Oops...',
							  html: 'Algo salió mal!',
							  footer: '<center>Toma una captura y enviala al soporte para ayudarte con el problema</center>'
						})
					}

				},
				error: function(xhr, status){

                    const errors =xhr.responseJSON.errors;
                    let errorMessage = 'Algo ha salido mal';
                    $.each(errors, function(key,value){
                        errorMessage = value[0];
                    })

					Swal.fire({
							  type: 'error',
 							  title: 'Error',
                              text: errorMessage,
							  footer: '<center>Toma una captura y enviala al soporte para ayudarte con el problema</center>'
						})
				},
				complete: function(xhr, status){

				}
			})
		}
		}



	});

});
